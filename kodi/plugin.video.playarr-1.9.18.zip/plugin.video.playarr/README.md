# Playarr for Kodi (`plugin.video.playarr`)

A native Kodi video add-on that replaces Kodi's built-in music video system with
your [Playarr](../../README.md) library. Browse by artist, album, year and
genre, search, shuffle the whole collection (Party Mode), and play your Playarr
playlists — with full metadata and artwork served straight from your Playarr
server.

## Features

- **Faceted browsing** — Artists, Albums, Years, Genres (counts shown), each
  drilling into a filtered video list.
- **All Videos + Search** — paginated full library and a keyword search.
- **Party Mode** — builds a weighted-random queue via `/api/library/party-mode`
  and plays it, exactly like the Playarr web UI. The exclusion filters you set
  in the web UI are stored on the server and applied automatically, so Kodi's
  Party Mode honours them with no extra configuration.
- **Shared defaults** — the default library sort/direction you pick in the web
  UI is saved server-side; Kodi's browse lists use it as their initial order.
- **Playlists** — browse your Playarr playlists; open one to see its tracks or
  use the context menu to play the whole list.
- **Two playback modes**
  - **Stream via Playarr API** (default) — plays the new `/api/playback/raw/{id}`
    endpoint. Works on any device on the network, zero setup, with correct
    seeking (no needless remuxing — Kodi decodes MKV/everything natively).
  - **Direct file path / share** — Kodi reads the original file off disk or an
    SMB/NFS share. Zero server CPU and the fastest seeking, but Kodi must be able
    to reach the files. Use the path-remap settings to rewrite the server's local
    path (e.g. `D:\Playarr\library`) to a Kodi-reachable one
    (e.g. `smb://nas/Playarr/library`).
- **Artwork & metadata** — posters, scene-frame fanart, artist/album/year/genre,
  plot and duration as Kodi `musicvideo` info.
- **Playback history** — optionally records each play back to Playarr.

## Requirements

- Kodi 19 (Matrix) or newer — Python 3.
- A running Playarr server reachable from the Kodi device.
- The Playarr backend must include the `/api/playback/raw/{id}` endpoint
  (Playarr ≥ the release that ships this add-on) for **stream** mode. **Direct**
  mode works against any Playarr version.

## Install

1. Zip the `plugin.video.playarr` folder so the archive's top-level entry is the
   `plugin.video.playarr/` directory (see `../README.md` for a one-liner).
2. In Kodi: **Settings → Add-ons → Install from zip file**, then pick the zip.
   (You may need to enable *Unknown sources* in **Settings → System → Add-ons**.)
3. Open the add-on; on first run set your server details in **Settings**.

## Adding Playarr to the home screen

Kodi add-ons can't insert their own item into the skin's main menu (the
Movies / TV Shows / Music sidebar entries) — the **skin** owns that menu — so
the option depends on which skin you run:

- **Quickest (any skin):** open the add-on and pick **Add Playarr to
  Favourites** (also under the add-on's **Settings → Home menu**). This creates
  a Kodi favourite that jumps straight to Playarr; skins that surface
  favourites on the home screen will show it there.
- **Estuary (default skin):** it doesn't support custom main-menu items. Use
  the favourite above, or pin Playarr via the favourites widget.
- **Skins with custom menus** (Arctic Horizon, Aeon Nox, etc.): in the skin's
  *Main menu* settings choose **Add menu item → Add-on → Playarr** to get a
  true sidebar entry.

## Settings

| Setting | Default | Notes |
|---|---|---|
| Playarr host or IP | `127.0.0.1` | Hostname/IP, or a full `http(s)://host:port` URL. |
| Port | `6969` | Ignored if the host field is a full URL. |
| Use HTTPS | off | Enable if Playarr is behind TLS. |
| Test connection | — | Pings `/api/version` and reports the server version. |
| Playback source | Stream via Playarr API | `Stream` or `Direct file path / share`. |
| Replace path prefix / with prefix | empty | Direct mode only — path remap for shares. |
| Items per page | `50` | Page size for the video lists. |
| Party Mode: max videos to queue | `200` | Caps the shuffle queue so a large library doesn't build a huge playlist (which can crash Kodi). |
| Record playback history | on | POSTs to `/api/playback/history/{id}` on play. |
| Add Playarr to Kodi Favourites | — | Creates a home/favourites shortcut to the add-on. |

## How it maps to Playarr's API

| Add-on action | Endpoint |
|---|---|
| Artists / Albums / Years / Genres | `/api/library/artists` `…/albums` `…/years` `…/genres` |
| Video lists & search | `/api/library/?page=&page_size=&artist=&album=&genre=&year=&search=` |
| Party Mode | `/api/library/party-mode` |
| Playlists | `/api/playlists/`, `/api/playlists/{id}` |
| Playback (stream) | `/api/playback/raw/{id}` |
| Playback (direct) | `file_path` from `/api/library/{id}` (optionally remapped) |
| Artwork | `/api/playback/poster/{id}`, `/api/playback/thumb/{id}`, `/api/playback/artwork/{id}/artist_thumb` (folder tiles use a representative video's images) |
| History | `POST /api/playback/history/{id}` |

The add-on uses only the Python standard library — no extra Kodi modules needed.
