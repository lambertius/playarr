# -*- coding: utf-8 -*-
"""
Playarr add-on — routing and directory/listing logic.

Every Kodi navigation calls run(argv); we dispatch on the ?action= param.
Browsing maps onto Playarr's /api/library facets; playback resolves a single
video either to the raw HTTP stream endpoint or to a (optionally remapped)
direct file path.
"""
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import kodiutils as ku
from resources.lib.api import PlayarrApi, PlayarrApiError


# ── Construction helpers ───────────────────────────────────

def _api():
    return PlayarrApi(ku.server_base())


def _add_dir(label, *, art=None, **params):
    """Add a navigable folder item to the current directory listing."""
    li = xbmcgui.ListItem(label=label)
    li.setArt(art or {"icon": ku.ADDON_ICON, "thumb": ku.ADDON_ICON,
                       "fanart": ku.ADDON_FANART})
    xbmcplugin.addDirectoryItem(
        handle=ku.handle(),
        url=ku.build_url(**params),
        listitem=li,
        isFolder=True,
    )


def _video_label(artist, title, version_type=None, resolution=None):
    label = u"{0} - {1}".format(artist or u"Unknown", title or u"Unknown")
    extra = []
    if version_type and version_type != "normal":
        extra.append(version_type.replace("_", " ").title())
    if resolution:
        extra.append(resolution)
    if extra:
        label = u"{0}  [{1}]".format(label, u" · ".join(extra))
    return label


def _apply_video_info(li, *, artist, title, album=None, year=None,
                      genres=None, plot=None, duration=None):
    """Populate musicvideo InfoLabels on a ListItem (Kodi 19+ compatible)."""
    info = {
        "mediatype": "musicvideo",
        "title": title or u"",
        "artist": [a.strip() for a in (artist or u"").split(";") if a.strip()],
    }
    if album:
        info["album"] = album
    if year:
        info["year"] = int(year)
        info["premiered"] = u"{0}-01-01".format(int(year))
    if genres:
        info["genre"] = genres
    if plot:
        info["plot"] = plot
    if duration:
        try:
            info["duration"] = int(float(duration))
        except (TypeError, ValueError):
            pass
    li.setInfo("video", info)


def _video_art(api, video_id, has_poster):
    art = {"fanart": ku.ADDON_FANART, "icon": ku.ADDON_ICON}
    if has_poster:
        poster = api.poster_url(video_id)
        art["poster"] = poster
        art["thumb"] = poster
        # The video player thumbnail (scene frame) makes nicer fanart when present.
        art["fanart"] = api.thumb_url(video_id)
    return art


def _first_video_id(row):
    """Representative video id for a facet row (artist/album/genre/year)."""
    ids = row.get("video_ids") or []
    return ids[0] if ids else None


def _facet_art(api, rep_id, *, artist=False):
    """Artwork for a browse folder, using a representative video's images so
    Artist/Album/Genre/Year tiles show real artwork instead of the add-on icon.

    Artists prefer the scraped artist image (artist_thumb) and fall back to the
    representative poster; everything else uses the poster.  Falls back to the
    add-on icon when the facet has no videos."""
    art = {"icon": ku.ADDON_ICON, "fanart": ku.ADDON_FANART}
    if rep_id is None:
        return art
    poster = api.poster_url(rep_id)
    if artist:
        thumb = api.artwork_url(rep_id, "artist_thumb")
        art["thumb"] = thumb
        art["poster"] = thumb
        # If the artist image is missing the skin falls back to the icon, so
        # point that at the album poster rather than the generic add-on logo.
        art["icon"] = poster
    else:
        art["thumb"] = poster
        art["poster"] = poster
        art["icon"] = poster
    return art


def _make_play_listitem(api, video_id, artist, title, *, album=None, year=None,
                        genres=None, plot=None, duration=None,
                        version_type=None, resolution=None, has_poster=False):
    """A playable ListItem whose path points back into the plugin (action=play)."""
    li = xbmcgui.ListItem(label=_video_label(artist, title, version_type, resolution))
    li.setProperty("IsPlayable", "true")
    _apply_video_info(li, artist=artist, title=title, album=album, year=year,
                      genres=genres, plot=plot, duration=duration)
    li.setArt(_video_art(api, video_id, has_poster))
    return li


def _add_videos(api, items, *, content="musicvideos"):
    """Render a list of video summary dicts as playable directory items."""
    xbmcplugin.setContent(ku.handle(), content)
    dir_items = []
    for v in items:
        vid = v.get("id") or v.get("video_id") or v.get("videoId")
        if vid is None:
            continue
        li = _make_play_listitem(
            api, vid,
            v.get("artist"), v.get("title"),
            album=v.get("album"),
            year=v.get("year"),
            duration=v.get("duration_seconds") or v.get("duration"),
            version_type=v.get("version_type"),
            resolution=v.get("resolution_label"),
            has_poster=bool(v.get("has_poster") or v.get("hasPoster")),
        )
        # Context menu: jump to this artist's videos.
        if v.get("artist"):
            li.addContextMenuItems([(
                u"Go to artist: {0}".format(v["artist"]),
                "Container.Update({0})".format(
                    ku.build_url(action="videos", artist=v["artist"])),
            )])
        dir_items.append((ku.build_url(action="play", id=vid), li, False))
    xbmcplugin.addDirectoryItems(ku.handle(), dir_items, len(dir_items))
    # SORT_METHOD_NONE keeps the server's order — which honours the default
    # library sort saved in Playarr's preferences — as the initial view.
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_VIDEO_YEAR)


def _end(succeeded=True, update=False):
    # Reached both from directory clicks (valid handle) and RunPlugin (handle -1).
    # endOfDirectory on a -1 handle just logs a Kodi error, so skip it.
    if ku.handle() >= 0:
        xbmcplugin.endOfDirectory(ku.handle(), succeeded=succeeded, updateListing=update)


# ── Menus ──────────────────────────────────────────────────

def root_menu():
    _add_dir(u"Artists", action="artists")
    _add_dir(u"Albums", action="albums")
    _add_dir(u"Years", action="years")
    _add_dir(u"Genres", action="genres")
    _add_dir(u"All Videos", action="videos")
    _add_dir(u"Search", action="search")
    _add_dir(u"Party Mode (shuffle all)", action="party")
    _add_dir(u"Playlists", action="playlists")
    _add_dir(u"Add Playarr to Favourites", action="addfav")
    _add_dir(u"Settings", action="settings")
    _end()


def list_artists():
    api = _api()
    rows = api.list_artists()
    xbmcplugin.setContent(ku.handle(), "artists")
    for r in rows:
        name = r.get("artist")
        if not name:
            continue
        _add_dir(u"{0} ({1})".format(name, r.get("count", 0)),
                 art=_facet_art(api, _first_video_id(r), artist=True),
                 action="videos", artist=name)
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_LABEL)
    _end()


def list_albums():
    api = _api()
    rows = api.list_albums()
    xbmcplugin.setContent(ku.handle(), "albums")
    for r in rows:
        album = r.get("album")
        if not album:
            continue
        artist = r.get("artist")
        label = u"{0}{1} ({2})".format(
            album, u" — {0}".format(artist) if artist else u"", r.get("count", 0))
        art = _facet_art(api, _first_video_id(r))
        if r.get("album_entity_id"):
            _add_dir(label, art=art, action="videos", album_entity_id=r["album_entity_id"])
        else:
            _add_dir(label, art=art, action="videos", album=album)
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_LABEL)
    _end()


def list_years():
    api = _api()
    rows = api.list_years()
    xbmcplugin.setContent(ku.handle(), "years")
    for r in rows:
        yr = r.get("year")
        if not yr:
            continue
        _add_dir(u"{0} ({1})".format(yr, r.get("count", 0)),
                 art=_facet_art(api, _first_video_id(r)),
                 action="videos", year=yr)
    _end()


def list_genres():
    api = _api()
    rows = api.list_genres()
    xbmcplugin.setContent(ku.handle(), "genres")
    for r in rows:
        g = r.get("genre")
        if not g:
            continue
        _add_dir(u"{0} ({1})".format(g, r.get("count", 0)),
                 art=_facet_art(api, _first_video_id(r)),
                 action="videos", genre=g)
    xbmcplugin.addSortMethod(ku.handle(), xbmcplugin.SORT_METHOD_LABEL)
    _end()


def list_videos(params):
    api = _api()
    page = int(params.get("page", 1))
    psize = ku.page_size()
    filters = {k: params[k] for k in
               ("artist", "album", "album_entity_id", "genre", "year", "search")
               if params.get(k)}
    try:
        data = api.list_videos(page=page, page_size=psize, **filters)
    except PlayarrApiError as exc:
        ku.error(str(exc))
        _end(succeeded=False)
        return
    items = (data or {}).get("items", [])
    _add_videos(api, items)

    total_pages = (data or {}).get("total_pages", 1)
    if page < total_pages:
        next_params = dict(params)
        next_params["action"] = "videos"
        next_params["page"] = page + 1
        _add_dir(u"Next page  ({0}/{1}) »".format(page + 1, total_pages),
                 **next_params)
    _end()


def search():
    term = ku.keyboard(u"Search Playarr library")
    if not term:
        _end(succeeded=False)
        return
    # Re-enter the video list with the search filter applied.
    list_videos({"search": term, "page": 1})


# ── Queue playback (party mode + playlists) ────────────────

def _queue_and_play(api, tracks):
    """Build the Kodi video playlist from track dicts and start playback.

    Each entry is a plugin:// URL (action=play) so Kodi resolves the real
    stream lazily when it reaches that track.

    Crash-safety: we release the originating directory handle *before* starting
    playback.  Playback re-enters the plugin (action=play) to resolve each
    item, and starting it while the folder's directory handle is still open can
    hang or crash Kodi.  `_end()` is a no-op when invoked via RunPlugin
    (handle -1), so this is safe from both folder clicks and context menus.
    """
    tracks = [t for t in (tracks or [])
              if (t.get("videoId") or t.get("video_id") or t.get("id"))]
    if not tracks:
        ku.notify(u"Nothing to play")
        _end(succeeded=False)
        return

    _end(succeeded=False)

    try:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        for t in tracks:
            vid = t.get("videoId") or t.get("video_id") or t.get("id")
            li = _make_play_listitem(
                api, vid,
                t.get("artist"), t.get("title"),
                duration=t.get("duration") or t.get("duration_seconds"),
                has_poster=bool(t.get("hasPoster") or t.get("has_poster")),
            )
            pl.add(ku.build_url(action="play", id=vid), li)
        xbmc.Player().play(pl)
    except Exception as exc:  # noqa: BLE001 — never let a bad track crash Kodi
        ku.log_error("Queue/play failed: {0}".format(exc))
        ku.error(u"Could not start playback")


def party_mode():
    api = _api()
    try:
        data = api.party_mode()
    except PlayarrApiError as exc:
        ku.error(str(exc))
        _end(succeeded=False)
        return
    tracks = (data or {}).get("tracks", [])
    limit = ku.party_limit()
    if len(tracks) > limit:
        tracks = tracks[:limit]
    ku.notify(u"Party Mode: queued {0} videos".format(len(tracks)))
    _queue_and_play(api, tracks)


def list_playlists():
    api = _api()
    try:
        rows = api.list_playlists()
    except PlayarrApiError as exc:
        ku.error(str(exc))
        _end(succeeded=False)
        return
    xbmcplugin.setContent(ku.handle(), "videos")
    for p in rows:
        label = u"{0} ({1})".format(p.get("name", u"Playlist"), p.get("entry_count", 0))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ku.ADDON_ICON, "fanart": ku.ADDON_FANART})
        if p.get("description"):
            li.setInfo("video", {"plot": p["description"]})
        # Folder opens entries; context menu plays the whole list at once.
        li.addContextMenuItems([(
            u"Play playlist",
            "RunPlugin({0})".format(ku.build_url(action="play_playlist", id=p["id"])),
        )])
        xbmcplugin.addDirectoryItem(
            ku.handle(),
            ku.build_url(action="playlist", id=p["id"]),
            li, isFolder=True,
        )
    _end()


def playlist_entries(playlist_id):
    api = _api()
    try:
        pl = api.get_playlist(playlist_id)
    except PlayarrApiError as exc:
        ku.error(str(exc))
        _end(succeeded=False)
        return
    entries = (pl or {}).get("entries", [])
    _add_videos(api, entries)
    _end()


def play_playlist(playlist_id):
    api = _api()
    try:
        pl = api.get_playlist(playlist_id)
    except PlayarrApiError as exc:
        ku.error(str(exc))
        return
    entries = (pl or {}).get("entries", [])
    _queue_and_play(api, entries)


# ── Single-video resolution ────────────────────────────────

def _resolve_play_path(api, detail):
    """Return the URL Kodi should actually open for this video."""
    video_id = detail.get("id")
    if ku.playback_mode() == "direct":
        file_path = detail.get("file_path")
        if file_path:
            remap_from, remap_to = ku.path_remap()
            if remap_from and remap_from in file_path:
                file_path = file_path.replace(remap_from, remap_to)
            # Network shares (smb://, nfs://) and POSIX paths use forward slashes.
            if remap_to and ("://" in remap_to or remap_to.startswith("/")):
                file_path = file_path.replace("\\", "/")
            return file_path
        ku.log_error("Direct mode but no file_path for video {0}; "
                     "falling back to stream".format(video_id))
    return api.raw_stream_url(video_id)


def _version_tuple(v):
    """Parse a dotted version string into a comparable tuple of ints."""
    parts = []
    for chunk in str(v or "").split("."):
        digits = u"".join(c for c in chunk if c.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def test_connection():
    """Settings 'Test connection' button — verify the server is reachable."""
    api = _api()
    try:
        info = api.ping()
    except PlayarrApiError as exc:
        ku.error(u"Connection failed: {0}".format(exc))
        return
    version = (info or {}).get("version") or (info or {}).get("app_version") or u"?"
    # Warn if the add-on and server versions differ on major.minor — the add-on
    # is distributed from the server (Settings → System → Kodi) so the two are
    # meant to stay matched.  Patch-level differences are tolerated silently.
    if _version_tuple(version)[:2] != _version_tuple(ku.ADDON_VERSION)[:2]:
        ku.error(
            u"Version mismatch: add-on {0} vs server {1}. "
            u"Re-download the Kodi add-on from Playarr settings.".format(
                ku.ADDON_VERSION, version),
        )
        return
    ku.notify(u"Connected to Playarr {0} at {1}".format(version, ku.server_base()))


def add_to_favourites():
    """Create a Kodi favourite that opens Playarr — the closest cross-skin
    equivalent of a home-menu shortcut (skins own the main menu, so an add-on
    can't add a sidebar item itself)."""
    if ku.add_favourite(ku.ADDON_NAME, ku.base_url(), ku.ADDON_ICON):
        ku.notify(u"Added Playarr to Favourites")
    else:
        ku.error(u"Could not add Playarr to Favourites")
    # No-op when launched via RunPlugin (handle -1); closes the folder cleanly
    # when launched from the root-menu item.
    _end(succeeded=False)


def play(video_id):
    api = _api()
    try:
        detail = api.get_video(video_id)
    except PlayarrApiError as exc:
        ku.error(str(exc))
        xbmcplugin.setResolvedUrl(ku.handle(), False, xbmcgui.ListItem())
        return
    if not detail:
        ku.error(u"Video {0} not found".format(video_id))
        xbmcplugin.setResolvedUrl(ku.handle(), False, xbmcgui.ListItem())
        return

    url = _resolve_play_path(api, detail)
    genres = [g.get("name") for g in (detail.get("genres") or []) if g.get("name")]
    qs = detail.get("quality_signature") or {}

    li = xbmcgui.ListItem(path=url)
    _apply_video_info(
        li,
        artist=detail.get("artist"),
        title=detail.get("title"),
        album=detail.get("album"),
        year=detail.get("year"),
        genres=genres,
        plot=detail.get("plot"),
        duration=qs.get("duration_seconds"),
    )
    li.setArt(_video_art(api, video_id,
                         any(a.get("asset_type") == "poster"
                             for a in (detail.get("media_assets") or []))))
    if qs.get("width") and qs.get("height"):
        li.addStreamInfo("video", {
            "codec": qs.get("video_codec") or "",
            "width": int(qs["width"]),
            "height": int(qs["height"]),
            "duration": int(qs.get("duration_seconds") or 0),
        })

    if ku.record_history():
        api.record_history(video_id, qs.get("duration_seconds"))

    xbmcplugin.setResolvedUrl(ku.handle(), True, li)


# ── Dispatch ───────────────────────────────────────────────

def run(argv):
    params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
    action = params.get("action")

    if action is None:
        root_menu()
    elif action == "artists":
        list_artists()
    elif action == "albums":
        list_albums()
    elif action == "years":
        list_years()
    elif action == "genres":
        list_genres()
    elif action == "videos":
        list_videos(params)
    elif action == "search":
        search()
    elif action == "party":
        party_mode()
    elif action == "playlists":
        list_playlists()
    elif action == "playlist":
        playlist_entries(int(params["id"]))
    elif action == "play_playlist":
        play_playlist(int(params["id"]))
    elif action == "play":
        play(int(params["id"]))
    elif action == "ping":
        test_connection()
    elif action == "addfav":
        add_to_favourites()
    elif action == "settings":
        ku.open_settings()
    else:
        ku.log_error("Unknown action: {0}".format(action))
        root_menu()
